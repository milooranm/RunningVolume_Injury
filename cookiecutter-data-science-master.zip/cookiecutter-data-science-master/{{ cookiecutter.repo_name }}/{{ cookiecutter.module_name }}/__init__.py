from {{ cookiecutter.module_name }} import config  # noqa: F401
