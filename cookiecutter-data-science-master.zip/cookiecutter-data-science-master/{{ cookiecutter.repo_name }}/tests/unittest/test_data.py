import unittest


class TestCodeIsTested(unittest.TestCase):

    def test_code_is_tested(self):
        self.assertTrue(False)


if __name__ == '__main__':
    unittest.main()
